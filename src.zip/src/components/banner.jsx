import '../styles/banner.css'
import youbanner from '../images/youtubebanner.jpg'

const Banner = () => {
   
    return (  
        <div>
            <div >
                <img className="banner" src={youbanner} alt="" />
            </div>

        </div>
        
    );
}
 
export default Banner;