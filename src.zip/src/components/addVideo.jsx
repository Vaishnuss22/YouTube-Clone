import '../styles/addVideo.css'
import  abstract from '../images/abstract.jpg'

const AddVideo=()=>{
    return (
        <div className="addVideo">
            <body>
                <section>
                    <div id="box1">
                        
                        <img className="abstact1" src={abstract} alt=""  />


                    </div>
                    <div id="box2">

                         <h1>Add Video</h1>
                         <form> 

                            <label htmlFor="">Title</label>
                            <input type="text" name="thumbnail" id="" />

                            <label htmlFor="">Channel</label>

                            <input type="text" name="title" id="" />

                            <label htmlFor="">Views</label>

                            <input type="text" name="channel" id="" />

                            <label htmlFor="">Title</label>

                            <input type="text" name="views" id="" />

                            <input type="checkbox" name="" id="" />
                            <p>I agree to the above <p>terms and coditions </p></p>
                            <button>Submit</button>

                         </form>


                    </div>
                </section>


            </body>
        </div>
    )
}

export default AddVideo;